'use client';

import { createTheme } from '@mui/material/styles';

export const theme = createTheme({
  cssVariables: true,
  colorSchemes: {
    light: {
      palette: {
        primary: { main: '#1976d2' },
        secondary: { main: '#9c27b0' }
      }
    }
  },
  components: {
    MuiContainer: {
      defaultProps: { maxWidth: 'md' }
    }
  }
});
